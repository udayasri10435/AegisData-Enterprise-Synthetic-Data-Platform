import React from 'react';
import { ArrowRight, Lock, Activity, Building2, Landmark, CheckCircle2 } from 'lucide-react';

interface HeroArchitectureProps {
  onSelectDomain: (domain: 'healthcare' | 'finance' | 'government') => void;
  onExploreWorkbench: () => void;
}

export const HeroArchitecture: React.FC<HeroArchitectureProps> = ({
  onSelectDomain,
  onExploreWorkbench,
}) => {
  return (
    <div className="relative overflow-hidden border-b border-slate-800/80 bg-slate-950 py-16 lg:py-20">
      {/* Background ambient lighting */}
      <div className="pointer-events-none absolute -top-40 left-1/2 -z-10 h-96 w-[700px] -translate-x-1/2 rounded-full bg-cyan-900/20 blur-3xl" />
      <div className="pointer-events-none absolute top-1/2 right-10 -z-10 h-72 w-72 rounded-full bg-emerald-950/30 blur-3xl" />

      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:items-center">
          
          {/* Left Column: Mechanism-to-Outcome value proposition */}
          <div className="lg:col-span-7">
            {/* Clean unboxed metadata separator */}
            <div className="mb-4 flex items-center gap-2 text-xs font-semibold text-cyan-400">
              <span>Differential Privacy Engine</span>
              <span aria-hidden="true">·</span>
              <span>HIPAA §164.514</span>
              <span aria-hidden="true">·</span>
              <span>FinCEN Compliant</span>
              <span aria-hidden="true">·</span>
              <span>FedRAMP High Ready</span>
            </div>

            <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl lg:text-5xl" style={{ textWrap: 'balance' }}>
              Mathematical Synthetic Data for Regulated AI & Machine Learning
            </h1>

            <p className="mt-5 max-w-2xl text-base leading-relaxed text-slate-300">
              Train neural networks, test high-stakes financial pipelines, and simulate public policy with zero point-to-point data leakage. AegisData replaces production databases with mathematically equivalent synthetic twins protected by tunable $\epsilon$-differential privacy.
            </p>

            {/* Claim-to-Proof Quantitative Adjacency */}
            <div className="mt-8 grid grid-cols-3 gap-6 border-y border-slate-800/80 py-5">
              <div>
                <div className="font-mono text-2xl font-bold tabular-nums text-white">0</div>
                <div className="mt-1 text-xs text-slate-400">Statutory PHI / PII identifiers leaked</div>
              </div>
              <div>
                <div className="font-mono text-2xl font-bold tabular-nums text-cyan-400">98.4%</div>
                <div className="mt-1 text-xs text-slate-400">ML downstream accuracy parity</div>
              </div>
              <div>
                <div className="font-mono text-2xl font-bold tabular-nums text-emerald-400">&lt; 2 min</div>
                <div className="mt-1 text-xs text-slate-400">Data access legal clearance time</div>
              </div>
            </div>

            {/* Action buttons & Domain jumpers */}
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button
                onClick={onExploreWorkbench}
                className="flex items-center gap-2 rounded-lg bg-cyan-600 px-5 py-3 text-sm font-semibold text-white shadow-md transition-colors hover:bg-cyan-500"
              >
                <span>Launch Synthetic Studio</span>
                <ArrowRight className="h-4 w-4" />
              </button>

              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span className="text-slate-500">Jump to Sector:</span>
                <button
                  onClick={() => onSelectDomain('healthcare')}
                  className="rounded border border-slate-800 bg-slate-900 px-2.5 py-1.5 font-medium text-slate-300 transition-colors hover:border-cyan-500 hover:text-white"
                >
                  Healthcare
                </button>
                <button
                  onClick={() => onSelectDomain('finance')}
                  className="rounded border border-slate-800 bg-slate-900 px-2.5 py-1.5 font-medium text-slate-300 transition-colors hover:border-emerald-500 hover:text-white"
                >
                  Finance
                </button>
                <button
                  onClick={() => onSelectDomain('government')}
                  className="rounded border border-slate-800 bg-slate-900 px-2.5 py-1.5 font-medium text-slate-300 transition-colors hover:border-indigo-500 hover:text-white"
                >
                  Government
                </button>
              </div>
            </div>
          </div>

          {/* Right Column: High-Fidelity SVG Cryptographic Architecture Topology */}
          <div className="lg:col-span-5">
            <div className="relative rounded-xl border border-slate-800 bg-slate-900/60 p-6 shadow-2xl backdrop-blur-sm">
              <div className="mb-4 flex items-center justify-between border-b border-slate-800 pb-3 text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-cyan-400" />
                  <span className="font-semibold text-slate-200">Zero-Leakage Privacy Architecture</span>
                </div>
                <span className="font-mono text-cyan-400">DP-ε Laplace Engine</span>
              </div>

              {/* Topology SVG */}
              <div className="w-full">
                <svg viewBox="0 0 460 300" className="w-full h-auto" fill="none">
                  {/* Background grid dots */}
                  <defs>
                    <pattern id="gridDots" width="20" height="20" patternUnits="userSpaceOnUse">
                      <circle cx="2" cy="2" r="1" fill="#334155" opacity="0.4" />
                    </pattern>
                    <linearGradient id="streamGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#ef4444" stopOpacity="0.8" />
                      <stop offset="50%" stopColor="#06b6d4" stopOpacity="1" />
                      <stop offset="100%" stopColor="#10b981" stopOpacity="0.9" />
                    </linearGradient>
                  </defs>
                  <rect width="460" height="300" fill="url(#gridDots)" />

                  {/* Flow Paths */}
                  <path d="M 90 90 C 150 90, 160 150, 230 150" stroke="#475569" strokeWidth="2" strokeDasharray="4 4" />
                  <path d="M 90 210 C 150 210, 160 150, 230 150" stroke="#475569" strokeWidth="2" strokeDasharray="4 4" />
                  <path d="M 230 150 C 300 150, 310 90, 370 90" stroke="url(#streamGrad)" strokeWidth="2.5" />
                  <path d="M 230 150 C 300 150, 310 210, 370 210" stroke="url(#streamGrad)" strokeWidth="2.5" />

                  {/* Node 1: Raw Silo A (PHI / PII) */}
                  <g transform="translate(20, 60)">
                    <rect width="130" height="60" rx="8" fill="#1e1b2e" stroke="#7f1d1d" strokeWidth="1.5" />
                    <text x="14" y="26" fill="#f87171" fontSize="11" fontWeight="bold">Raw Clinical Silo</text>
                    <text x="14" y="44" fill="#94a3b8" fontSize="9">100% PHI / Real Patients</text>
                  </g>

                  {/* Node 2: Raw Silo B (Financial Ledger) */}
                  <g transform="translate(20, 180)">
                    <rect width="130" height="60" rx="8" fill="#1e1b2e" stroke="#7f1d1d" strokeWidth="1.5" />
                    <text x="14" y="26" fill="#f87171" fontSize="11" fontWeight="bold">Production Ledgers</text>
                    <text x="14" y="44" fill="#94a3b8" fontSize="9">Restricted PCI & PII Data</text>
                  </g>

                  {/* Central Node: Differential Privacy Cryptographic Prism */}
                  <g transform="translate(170, 105)">
                    <rect width="120" height="90" rx="10" fill="#082f49" stroke="#0284c7" strokeWidth="2" />
                    <circle cx="60" cy="30" r="14" fill="#0369a1" />
                    <text x="56" y="34" fill="#bae6fd" fontSize="12" fontWeight="bold">ε</text>
                    <text x="14" y="60" fill="#e0f2fe" fontSize="11" fontWeight="bold">Aegis Core DP</text>
                    <text x="14" y="76" fill="#7dd3fc" fontSize="9">Laplace & Copula Engine</text>
                  </g>

                  {/* Node 3: Output Synthetic Twin (ML Training) */}
                  <g transform="translate(320, 60)">
                    <rect width="130" height="60" rx="8" fill="#064e3b" stroke="#059669" strokeWidth="1.5" />
                    <text x="14" y="26" fill="#6ee7b7" fontSize="11" fontWeight="bold">Synthetic Twin ML</text>
                    <text x="14" y="44" fill="#a7f3d0" fontSize="9">Safe for PyTorch / Cloud</text>
                  </g>

                  {/* Node 4: Output Sandbox (QA & Chaos Testing) */}
                  <g transform="translate(320, 180)">
                    <rect width="130" height="60" rx="8" fill="#064e3b" stroke="#059669" strokeWidth="1.5" />
                    <text x="14" y="26" fill="#6ee7b7" fontSize="11" fontWeight="bold">Third-Party QA</text>
                    <text x="14" y="44" fill="#a7f3d0" fontSize="9">Contractor Safe / Zero PHI</text>
                  </g>
                </svg>
              </div>

              {/* Guarantees Checklist */}
              <div className="mt-4 space-y-2 border-t border-slate-800 pt-3 text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span>Bounded Membership Inference Risk (&lt; 0.05%)</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span>Preserves Multi-variate Covariance for XGBoost & Neural Nets</span>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
