import React, { useState } from 'react';
import { X, Download, FileSpreadsheet, FileCode, Terminal, Copy, Check } from 'lucide-react';
import { exportToCSV, exportToSQL } from '../utils/syntheticData';

interface ExportPipelineModalProps {
  isOpen: boolean;
  onClose: () => void;
  dataset: Record<string, any>[];
  domain: string;
}

export const ExportPipelineModal: React.FC<ExportPipelineModalProps> = ({
  isOpen,
  onClose,
  dataset,
  domain,
}) => {
  const [activeSnippetTab, setActiveSnippetTab] = useState<'python' | 'curl' | 'sql'>('python');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const downloadFile = (content: string, filename: string, type: string) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadCSV = () => {
    const csv = exportToCSV(dataset);
    downloadFile(csv, `aegisdata_${domain}_synthetic_${Date.now()}.csv`, 'text/csv');
  };

  const handleDownloadJSON = () => {
    const jsonStr = JSON.stringify(dataset, null, 2);
    downloadFile(jsonStr, `aegisdata_${domain}_synthetic_${Date.now()}.json`, 'application/json');
  };

  const handleDownloadSQL = () => {
    const sql = exportToSQL(`synthetic_${domain}_records`, dataset);
    downloadFile(sql, `aegisdata_${domain}_synthetic_${Date.now()}.sql`, 'text/plain');
  };

  const pythonSnippet = `# PyTorch / Scikit-Learn Pipeline Integration
import pandas as pd
import requests

# Direct synthetic batch pull via AegisData REST
response = requests.post(
    "https://api.aegisdata.internal/v1/generate",
    headers={"Authorization": "Bearer aegis_live_sandbox_token"},
    json={
        "domain": "${domain}",
        "record_count": ${dataset.length},
        "epsilon": 1.0,
        "format": "pandas"
    }
)

df_synthetic = pd.DataFrame(response.json()["records"])
print(f"Loaded {len(df_synthetic)} privacy-safe records with 0 statutory PHI.")

# Ready for immediate model training without IRB/DPA delay
from sklearn.model_selection import train_test_split
X = df_synthetic.drop(columns=["patient_id" if "${domain}" == "healthcare" else "transaction_id"])
`;

  const curlSnippet = `curl -X POST "https://api.aegisdata.internal/v1/generate" \\
  -H "Authorization: Bearer aegis_live_sandbox_token" \\
  -H "Content-Type: application/json" \\
  -d '{
    "domain": "${domain}",
    "record_count": 500,
    "epsilon": 1.0,
    "k_anonymity": 10
  }'`;

  const sqlPreview = exportToSQL(`synthetic_${domain}_records`, dataset);

  const activeSnippetContent =
    activeSnippetTab === 'python' ? pythonSnippet : activeSnippetTab === 'curl' ? curlSnippet : sqlPreview;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(activeSnippetContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-3xl rounded-2xl border border-slate-800 bg-slate-900 shadow-2xl p-6 lg:p-8 max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-950/50 border border-cyan-800 text-cyan-400">
              <Download className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Export Dataset & ML Pipelines</h2>
              <div className="text-xs text-slate-400 font-mono">Ready for PyTorch, Snowflake, BigQuery, or Local S3</div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Direct Download Action Cards */}
        <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-3">
          <button
            onClick={handleDownloadCSV}
            className="flex flex-col items-start rounded-xl border border-slate-800 bg-slate-950 p-4 text-left transition-colors hover:border-cyan-500 hover:bg-slate-900"
          >
            <FileSpreadsheet className="h-6 w-6 text-cyan-400 mb-2" />
            <div className="text-xs font-bold text-white">Download CSV</div>
            <div className="text-[11px] text-slate-500">Comma-separated flat table</div>
          </button>

          <button
            onClick={handleDownloadJSON}
            className="flex flex-col items-start rounded-xl border border-slate-800 bg-slate-950 p-4 text-left transition-colors hover:border-cyan-500 hover:bg-slate-900"
          >
            <FileCode className="h-6 w-6 text-emerald-400 mb-2" />
            <div className="text-xs font-bold text-white">Download JSON</div>
            <div className="text-[11px] text-slate-500">Structured array payload</div>
          </button>

          <button
            onClick={handleDownloadSQL}
            className="flex flex-col items-start rounded-xl border border-slate-800 bg-slate-950 p-4 text-left transition-colors hover:border-cyan-500 hover:bg-slate-900"
          >
            <Terminal className="h-6 w-6 text-indigo-400 mb-2" />
            <div className="text-xs font-bold text-white">Download SQL DDL</div>
            <div className="text-[11px] text-slate-500">CREATE TABLE & Inserts</div>
          </button>
        </div>

        {/* Code Snippet Tabs */}
        <div className="mt-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveSnippetTab('python')}
                className={`text-xs font-semibold px-2 py-1 rounded transition-colors ${
                  activeSnippetTab === 'python' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Python & PyTorch
              </button>
              <button
                onClick={() => setActiveSnippetTab('curl')}
                className={`text-xs font-semibold px-2 py-1 rounded transition-colors ${
                  activeSnippetTab === 'curl' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                cURL REST API
              </button>
              <button
                onClick={() => setActiveSnippetTab('sql')}
                className={`text-xs font-semibold px-2 py-1 rounded transition-colors ${
                  activeSnippetTab === 'sql' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                SQL Schema DDL
              </button>
            </div>

            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1 text-xs text-slate-400 hover:text-white"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy Code'}</span>
            </button>
          </div>

          <pre className="mt-3 max-h-64 overflow-auto rounded-xl bg-slate-950 p-4 font-mono text-[11px] text-cyan-300 border border-slate-800">
            {activeSnippetContent}
          </pre>
        </div>

        {/* Footer */}
        <div className="mt-6 flex justify-end border-t border-slate-800 pt-4">
          <button
            onClick={onClose}
            className="rounded-lg bg-slate-800 px-4 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-700"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
