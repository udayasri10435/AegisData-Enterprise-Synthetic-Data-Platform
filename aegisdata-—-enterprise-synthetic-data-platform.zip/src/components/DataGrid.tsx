import React, { useState, useMemo } from 'react';
import { Search, ChevronLeft, ChevronRight, ArrowUpDown, Shield } from 'lucide-react';
import { FieldDefinition } from '../utils/syntheticData';

interface DataGridProps {
  data: Record<string, any>[];
  fields: FieldDefinition[];
  domain: string;
}

export const DataGrid: React.FC<DataGridProps> = ({ data, fields, domain }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<string | null>(null);
  const [sortAsc, setSortAsc] = useState(true);
  const [page, setPage] = useState(1);
  const pageSize = 12;

  // Filter by search query across all string values
  const filteredData = useMemo(() => {
    if (!searchTerm.trim()) return data;
    const term = searchTerm.toLowerCase();
    return data.filter((row) =>
      Object.values(row).some((val) => String(val).toLowerCase().includes(term))
    );
  }, [data, searchTerm]);

  // Sort
  const sortedData = useMemo(() => {
    if (!sortField) return filteredData;
    return [...filteredData].sort((a, b) => {
      const valA = a[sortField];
      const valB = b[sortField];
      if (typeof valA === 'number' && typeof valB === 'number') {
        return sortAsc ? valA - valB : valB - valA;
      }
      return sortAsc
        ? String(valA).localeCompare(String(valB))
        : String(valB).localeCompare(String(valA));
    });
  }, [filteredData, sortField, sortAsc]);

  // Pagination
  const totalPages = Math.ceil(sortedData.length / pageSize) || 1;
  const currentPage = Math.min(page, totalPages);
  const paginatedRows = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sortedData.slice(start, start + pageSize);
  }, [sortedData, currentPage, pageSize]);

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
  };

  if (!data.length) {
    return (
      <div className="flex h-64 flex-col items-center justify-center rounded-xl border border-slate-800 bg-slate-900/40 text-center p-6">
        <Shield className="h-8 w-8 text-slate-500 mb-2" />
        <div className="text-sm font-medium text-slate-300">No synthetic records generated yet</div>
        <div className="text-xs text-slate-500 mt-1">Configure your privacy budget and click &apos;Generate Dataset&apos; above.</div>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900/60 shadow-lg backdrop-blur-sm">
      {/* Top search & metadata bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 px-5 py-3">
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setPage(1);
              }}
              placeholder="Filter synthetic records..."
              className="h-8 w-56 rounded-md border border-slate-700 bg-slate-950 pl-8 pr-3 text-xs text-slate-200 placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
            />
          </div>
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="text-[11px] text-slate-400 hover:text-white"
            >
              Clear
            </button>
          )}
        </div>

        {/* Clean unboxed row count indicator */}
        <div className="flex items-center gap-2 text-xs text-slate-400 font-mono tabular-nums">
          <span>{filteredData.length} records</span>
          <span aria-hidden="true">·</span>
          <span>{fields.length} columns</span>
          <span aria-hidden="true">·</span>
          <span>Zero PHI</span>
        </div>
      </div>

      {/* High-Density Data Grid Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-slate-300">
          <thead className="bg-slate-950/80 text-[11px] font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-800">
            <tr>
              {fields.map((f) => (
                <th
                  key={f.name}
                  onClick={() => handleSort(f.name)}
                  className="cursor-pointer select-none px-4 py-3 hover:text-white whitespace-nowrap"
                >
                  <div className="flex items-center gap-1.5">
                    <span>{f.label}</span>
                    <ArrowUpDown className="h-3 w-3 text-slate-600" />
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/50 font-mono text-[11px]">
            {paginatedRows.map((row, idx) => (
              <tr
                key={idx}
                className="transition-colors hover:bg-slate-800/40"
              >
                {fields.map((f) => {
                  const val = row[f.name];
                  const isTarget = f.category === 'target';
                  const isId = f.category === 'identifier';
                  const isBoolean = typeof val === 'boolean';

                  return (
                    <td
                      key={f.name}
                      className={`px-4 py-2.5 whitespace-nowrap tabular-nums ${
                        isTarget
                          ? 'font-bold text-cyan-400'
                          : isId
                          ? 'text-slate-500'
                          : 'text-slate-300'
                      }`}
                    >
                      {isBoolean ? (
                        <span className={val ? 'text-rose-400 font-semibold' : 'text-emerald-400'}>
                          {val ? 'TRUE' : 'FALSE'}
                        </span>
                      ) : val !== undefined && val !== null ? (
                        typeof val === 'number' && !Number.isInteger(val) ? (
                          val.toFixed(2)
                        ) : (
                          String(val)
                        )
                      ) : (
                        <span className="text-slate-600">null</span>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination controls */}
      <div className="flex items-center justify-between border-t border-slate-800 px-5 py-3 text-xs text-slate-400">
        <div>
          Showing <span className="font-mono tabular-nums text-white">{(currentPage - 1) * pageSize + 1}</span> to{' '}
          <span className="font-mono tabular-nums text-white">{Math.min(currentPage * pageSize, filteredData.length)}</span> of{' '}
          <span className="font-mono tabular-nums text-white">{filteredData.length}</span> entries
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="flex h-7 w-7 items-center justify-center rounded border border-slate-800 bg-slate-950 text-slate-400 hover:text-white disabled:opacity-30 disabled:hover:text-slate-400"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <span className="px-2 font-mono tabular-nums text-slate-300">
            {currentPage} / {totalPages}
          </span>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage >= totalPages}
            className="flex h-7 w-7 items-center justify-center rounded border border-slate-800 bg-slate-950 text-slate-400 hover:text-white disabled:opacity-30 disabled:hover:text-slate-400"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
