import React, { useState, useMemo } from 'react';
import { DollarSign, Clock, ShieldCheck, Check, Key, Copy, CheckCircle } from 'lucide-react';

export const EnterpriseRoiCalculator: React.FC = () => {
  const [sector, setSector] = useState<'healthcare' | 'finance' | 'government'>('healthcare');
  const [teamSize, setTeamSize] = useState<number>(25);
  const [waitTimeDays, setWaitTimeDays] = useState<number>(120);
  const [projectsPerYear, setProjectsPerYear] = useState<number>(12);

  // Enterprise Lead Capture & Sandbox Token Generator State
  const [orgName, setOrgName] = useState('');
  const [workEmail, setWorkEmail] = useState('');
  const [generatedToken, setGeneratedToken] = useState<string | null>(null);
  const [tokenCopied, setTokenCopied] = useState(false);

  // Dynamic ROI Calculations
  const calculations = useMemo(() => {
    // Average salary per data scientist / ML engineer ~ $180,000 / year ($90/hour, $720/day)
    const costPerEngineerDay = 720;
    // Fractional idle/blocked time waiting for compliance approval (~20% overhead per day of lag)
    const developerDaysBlockedPerProject = Math.min(waitTimeDays * 0.25, 45);
    const totalBlockedDays = Math.round(developerDaysBlockedPerProject * projectsPerYear * (teamSize / 10));
    
    // Legal review & external compliance counsel hours per request ~ $4,500
    const legalCostPerProject = sector === 'healthcare' ? 6500 : sector === 'finance' ? 7500 : 5000;
    const directLegalSavings = legalCostPerProject * projectsPerYear;
    
    // Total annual dollar savings
    const developerProductivityGains = totalBlockedDays * costPerEngineerDay;
    const totalAnnualSavings = directLegalSavings + developerProductivityGains;

    // Breach Liability Avoidance
    const statutoryLiabilityCap =
      sector === 'healthcare'
        ? '$12.5M (HIPAA OCR Maximum Tier)'
        : sector === 'finance'
        ? '$25M (PCI-DSS & FinCEN Penalty Pool)'
        : 'Zero Statutory Liability (Title 13 Safe Harbor)';

    return {
      totalBlockedDays,
      directLegalSavings,
      developerProductivityGains,
      totalAnnualSavings,
      statutoryLiabilityCap,
    };
  }, [sector, teamSize, waitTimeDays, projectsPerYear]);

  const handleGenerateSandboxToken = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orgName || !workEmail) return;

    // Generate instantaneous synthetic enterprise sandbox token
    const token = `aegis_${sector.slice(0, 2)}_live_${Math.random().toString(36).substring(2, 10)}_${Date.now().toString(36)}`;
    setGeneratedToken(token);
  };

  const handleCopyToken = () => {
    if (!generatedToken) return;
    navigator.clipboard.writeText(generatedToken);
    setTokenCopied(true);
    setTimeout(() => setTokenCopied(false), 2000);
  };

  return (
    <div className="space-y-10 py-4">
      {/* Section Title */}
      <div className="max-w-2xl">
        <div className="text-xs font-semibold text-cyan-400">Enterprise Procurement & Value Proof</div>
        <h2 className="mt-1 text-2xl font-bold tracking-tight text-white sm:text-3xl">
          Quantify Your Data Governance ROI
        </h2>
        <p className="mt-2 text-sm text-slate-400">
          Calculate the engineering hours, legal review fees, and compliance risk eliminated by switching from restricted production data silos to AegisData synthetic twins.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
        
        {/* Left 6 Cols: Interactive Input Sliders */}
        <div className="lg:col-span-6 rounded-2xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl space-y-6">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white">Organization Parameters</h3>
          </div>

          {/* Sector Segmented Control */}
          <div>
            <label className="text-xs font-semibold text-slate-300">Industry / Regulatory Sector</label>
            <div className="mt-2 grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setSector('healthcare')}
                className={`rounded-lg py-2 text-xs font-medium transition-colors ${
                  sector === 'healthcare'
                    ? 'bg-cyan-600 text-white'
                    : 'border border-slate-800 bg-slate-950 text-slate-400 hover:text-white'
                }`}
              >
                Healthcare
              </button>
              <button
                type="button"
                onClick={() => setSector('finance')}
                className={`rounded-lg py-2 text-xs font-medium transition-colors ${
                  sector === 'finance'
                    ? 'bg-emerald-600 text-white'
                    : 'border border-slate-800 bg-slate-950 text-slate-400 hover:text-white'
                }`}
              >
                Banking / FinTech
              </button>
              <button
                type="button"
                onClick={() => setSector('government')}
                className={`rounded-lg py-2 text-xs font-medium transition-colors ${
                  sector === 'government'
                    ? 'bg-indigo-600 text-white'
                    : 'border border-slate-800 bg-slate-950 text-slate-400 hover:text-white'
                }`}
              >
                Government / Civic
              </button>
            </div>
          </div>

          {/* Team Size Slider */}
          <div>
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-slate-300">Data Science & ML Engineering Team</span>
              <span className="font-mono tabular-nums text-cyan-400 font-bold">{teamSize} engineers</span>
            </div>
            <input
              type="range"
              min="5"
              max="200"
              step="5"
              value={teamSize}
              onChange={(e) => setTeamSize(Number(e.target.value))}
              className="mt-2 h-2 w-full cursor-pointer appearance-none rounded-lg bg-slate-800 accent-cyan-500"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
              <span>5 engineers</span>
              <span>100 engineers</span>
              <span>200+ engineers</span>
            </div>
          </div>

          {/* Average Data Access Wait Time */}
          <div>
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-slate-300">Current Production Data Clearance Wait Time</span>
              <span className="font-mono tabular-nums text-amber-400 font-bold">{waitTimeDays} days</span>
            </div>
            <input
              type="range"
              min="14"
              max="240"
              step="7"
              value={waitTimeDays}
              onChange={(e) => setWaitTimeDays(Number(e.target.value))}
              className="mt-2 h-2 w-full cursor-pointer appearance-none rounded-lg bg-slate-800 accent-cyan-500"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
              <span>2 weeks (Fast)</span>
              <span>4 months (Typical)</span>
              <span>8 months (Heavily Siloed)</span>
            </div>
          </div>

          {/* Projects per year */}
          <div>
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-slate-300">ML Model & Analytics Projects / Year</span>
              <span className="font-mono tabular-nums text-white font-bold">{projectsPerYear} projects</span>
            </div>
            <input
              type="range"
              min="2"
              max="40"
              step="1"
              value={projectsPerYear}
              onChange={(e) => setProjectsPerYear(Number(e.target.value))}
              className="mt-2 h-2 w-full cursor-pointer appearance-none rounded-lg bg-slate-800 accent-cyan-500"
            />
          </div>

        </div>

        {/* Right 6 Cols: Real-Time Calculated ROI Projection */}
        <div className="lg:col-span-6 rounded-2xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl flex flex-col justify-between space-y-6">
          <div>
            <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
              <h3 className="text-sm font-bold text-white">Annual Financial & Operational Return</h3>
              <span className="text-[11px] font-mono text-emerald-400">Verified Model</span>
            </div>

            {/* Big Headline Metric */}
            <div className="mt-6 rounded-xl border border-emerald-900/40 bg-emerald-950/20 p-5">
              <div className="text-xs font-semibold text-emerald-400">Total Projected Annual Value</div>
              <div className="mt-1 font-mono text-3xl font-extrabold tabular-nums text-white lg:text-4xl">
                ${(calculations.totalAnnualSavings / 1000).toFixed(0)}k{' '}
                <span className="text-xs font-sans font-normal text-slate-400">/ year</span>
              </div>
              <p className="mt-2 text-xs text-slate-300">
                Combined legal review savings and engineering velocity acceleration across {projectsPerYear} projects.
              </p>
            </div>

            {/* Breakdown Grid */}
            <div className="mt-5 grid grid-cols-2 gap-4">
              <div className="rounded-xl border border-slate-800 bg-slate-950 p-4">
                <div className="text-[11px] text-slate-400">Developer Time Reclaimed</div>
                <div className="mt-1 font-mono text-xl font-bold tabular-nums text-white">
                  {calculations.totalBlockedDays} <span className="text-xs font-normal text-slate-500">days</span>
                </div>
                <div className="mt-1 text-[10px] text-slate-500">Saved from legal clearance blocking</div>
              </div>

              <div className="rounded-xl border border-slate-800 bg-slate-950 p-4">
                <div className="text-[11px] text-slate-400">Direct Compliance Savings</div>
                <div className="mt-1 font-mono text-xl font-bold tabular-nums text-cyan-400">
                  ${(calculations.directLegalSavings / 1000).toFixed(0)}k
                </div>
                <div className="mt-1 text-[10px] text-slate-500">Reduced DPA & IRB review billables</div>
              </div>
            </div>

            {/* Risk Avoidance Callout */}
            <div className="mt-4 rounded-xl border border-slate-800 bg-slate-950 p-4">
              <div className="text-[11px] text-slate-400">Statutory Fine & Breach Risk Exposure</div>
              <div className="mt-0.5 text-xs font-bold text-emerald-400">
                Reduced to $0.00
              </div>
              <div className="mt-1 text-[10px] text-slate-500">
                Protected against statutory fines up to {calculations.statutoryLiabilityCap}.
              </div>
            </div>
          </div>

          {/* Certifications footer */}
          <div className="border-t border-slate-800 pt-4 flex flex-wrap items-center justify-between text-xs text-slate-400">
            <span>SOC2 Type II</span>
            <span>·</span>
            <span>FedRAMP High In-Process</span>
            <span>·</span>
            <span>HIPAA BAA Standard</span>
            <span>·</span>
            <span>ISO 27701</span>
          </div>
        </div>

      </div>

      {/* Sandbox Access & Enterprise Token Dispatch Container */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6 lg:p-8">
        <div className="max-w-2xl">
          <h3 className="text-lg font-bold text-white">Instant Enterprise Sandbox Clearance</h3>
          <p className="mt-1 text-xs text-slate-400">
            Generate an instant sandbox authentication token to test synthetic pipelines with your team or orchestrate automated CI/CD chaos tests.
          </p>
        </div>

        {!generatedToken ? (
          <form onSubmit={handleGenerateSandboxToken} className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div>
              <label className="text-xs font-medium text-slate-300">Enterprise / Agency Name</label>
              <input
                type="text"
                required
                value={orgName}
                onChange={(e) => setOrgName(e.target.value)}
                placeholder="e.g. Mayo Clinic / Goldman Sachs"
                className="mt-1 h-9 w-full rounded-md border border-slate-700 bg-slate-950 px-3 text-xs text-slate-200 placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300">Corporate / Gov Email</label>
              <input
                type="email"
                required
                value={workEmail}
                onChange={(e) => setWorkEmail(e.target.value)}
                placeholder="name@organization.com"
                className="mt-1 h-9 w-full rounded-md border border-slate-700 bg-slate-950 px-3 text-xs text-slate-200 placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
              />
            </div>

            <div className="flex items-end">
              <button
                type="submit"
                className="flex h-9 w-full items-center justify-center gap-2 rounded-md bg-cyan-600 px-4 text-xs font-semibold text-white shadow-sm hover:bg-cyan-500"
              >
                <Key className="h-4 w-4" />
                <span>Issue Sandbox Token</span>
              </button>
            </div>
          </form>
        ) : (
          <div className="mt-6 rounded-xl border border-cyan-800/60 bg-slate-950 p-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-emerald-400" />
                <span className="text-xs font-semibold text-white">
                  Enterprise Sandbox Active for {orgName}
                </span>
              </div>
              <button
                onClick={handleCopyToken}
                className="flex items-center gap-1.5 rounded border border-slate-700 bg-slate-900 px-2.5 py-1 text-xs text-slate-300 hover:text-white"
              >
                <Copy className="h-3.5 w-3.5" />
                <span>{tokenCopied ? 'Copied!' : 'Copy Bearer'}</span>
              </button>
            </div>

            <div className="mt-3 font-mono text-xs text-cyan-400 bg-slate-900 p-2.5 rounded border border-slate-800 break-all select-all">
              {generatedToken}
            </div>

            <div className="mt-3 flex items-center justify-between text-[11px] text-slate-400">
              <span>Rate Limit: 10,000 synthetic records / sec</span>
              <span>Expires: 30 days</span>
            </div>
          </div>
        )}
      </div>

    </div>
  );
};
