import React from 'react';
import { Activity, Building2, Landmark, Check, ArrowRight } from 'lucide-react';
import { DOMAIN_SCHEMAS } from '../utils/syntheticData';

interface DomainShowcaseProps {
  selectedDomain: 'healthcare' | 'finance' | 'government';
  onSelectDomain: (domain: 'healthcare' | 'finance' | 'government') => void;
  onLaunchWithDomain: (domain: 'healthcare' | 'finance' | 'government') => void;
}

export const DomainShowcase: React.FC<DomainShowcaseProps> = ({
  selectedDomain,
  onSelectDomain,
  onLaunchWithDomain,
}) => {
  const domains = [
    {
      id: 'healthcare' as const,
      title: 'Healthcare & Life Sciences',
      badge: 'HIPAA Safe Harbor · FDA 21 CFR 11',
      icon: Activity,
      accentColor: 'border-cyan-500/50 hover:border-cyan-400',
      activeColor: 'border-cyan-500 bg-cyan-950/20',
      description:
        'Generate clinical cohorts, longitudinal Electronic Health Records (EHR), and pharmacogenomic profiles without exposing protected health information.',
      challenges: [
        'IRB and HIPAA legal reviews delay ML projects by 6-9 months',
        'Cross-institutional collaboration blocked by PHI re-identification fear',
        'Imbalanced rare disease clinical trial datasets',
      ],
      capabilities: [
        'Preserves vital sign covariance (Systolic/Diastolic BP, LDL cholesterol)',
        'Hierarchical ICD-10 and SNOMED-CT clinical diagnostic codes',
        'Synthetic narrative doctor discharge summaries (Zero HIPAA 18 identifiers)',
        'Strict k-anonymity (k ≥ 10) on quasi-identifiers (Age, Sex, 3-digit Zip)',
      ],
    },
    {
      id: 'finance' as const,
      title: 'Banking & Financial Services',
      badge: 'FinCEN BSA · PCI-DSS v4.0 · Basel III',
      icon: Building2,
      accentColor: 'border-emerald-500/50 hover:border-emerald-400',
      activeColor: 'border-emerald-500 bg-emerald-950/20',
      description:
        'High-velocity transaction ledgers, credit risk defaults, and cross-border payment vectors with realistic synthetic fraud injection.',
      challenges: [
        'Real fraud vectors account for < 0.1% of transactions (severe class imbalance)',
        'PCI-DSS and Gramm-Leach-Bliley prohibit sharing cardholder data with external vendors',
        'Regulatory stress-testing requires extreme tail-risk scenario simulation',
      ],
      capabilities: [
        'Log-normal and power-law distribution models for transaction amounts ($2 to $100k+)',
        'Multi-variate correlation: Credit Score (300-850) vs Debt-to-Income vs Default',
        'Injectable AML typology vectors: Structuring, Layering, Velocity Bursts',
        'Cryptographic token generation with zero cardholder account leakage',
      ],
    },
    {
      id: 'government' as const,
      title: 'Government & Public Sector',
      badge: 'FedRAMP High · Title 13 U.S.C. · FIPS 140-3',
      icon: Landmark,
      accentColor: 'border-indigo-500/50 hover:border-indigo-400',
      activeColor: 'border-indigo-500 bg-indigo-950/20',
      description:
        'Demographic census datasets, benefits eligibility simulation, and municipal transit optimization under formal differential privacy bounds.',
      challenges: [
        'Title 13 federal statutory penalties prohibit individual record disclosure',
        'Need to share granular microdata with academic and policy researchers',
        'Legacy perturbation methods destroy demographic micro-correlations',
      ],
      capabilities: [
        'Census-grade top-coding and Laplace differential privacy bounded noise',
        'Preserved demographic covariance across education, income, and household size',
        'Municipal transit access and public benefits allocation simulation',
        'NIST SP 800-90A CSPRNG deterministic replay verification',
      ],
    },
  ];

  const current = domains.find((d) => d.id === selectedDomain) || domains[0];
  const schema = DOMAIN_SCHEMAS[selectedDomain];

  return (
    <section className="py-16 lg:py-24">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl">
          <div className="text-xs font-semibold text-cyan-400">Enterprise Domain Solutions</div>
          <h2 className="mt-2 text-2xl font-bold tracking-tight text-white sm:text-3xl">
            Engineered for Heavily Regulated Enterprise Environments
          </h2>
          <p className="mt-3 text-sm text-slate-400">
            Select a target sector to review pre-calibrated statistical schemas, compliance boundaries, and verified risk mitigation profiles.
          </p>
        </div>

        {/* Sector Tabs (Segmented functional controls) */}
        <div className="mt-8 grid grid-cols-1 gap-4 md:grid-cols-3">
          {domains.map((domain) => {
            const Icon = domain.icon;
            const isSelected = selectedDomain === domain.id;
            return (
              <button
                key={domain.id}
                onClick={() => onSelectDomain(domain.id)}
                className={`flex flex-col items-start rounded-xl border p-5 text-left transition-all ${
                  isSelected
                    ? domain.activeColor + ' shadow-lg'
                    : 'border-slate-800 bg-slate-900/40 hover:border-slate-700'
                }`}
              >
                <div className="flex w-full items-center justify-between">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-800 text-slate-200">
                    <Icon className="h-5 w-5" />
                  </div>
                  <span className="text-[11px] font-medium text-slate-400">{domain.badge}</span>
                </div>
                <div className="mt-4 text-base font-bold text-white">{domain.title}</div>
                <div className="mt-1 text-xs text-slate-400 line-clamp-2">{domain.description}</div>
              </button>
            );
          })}
        </div>

        {/* Detailed Domain Deep-Dive Container */}
        <div className="mt-8 rounded-2xl border border-slate-800 bg-slate-900/50 p-6 lg:p-8">
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
            
            {/* Left 6 cols: Problem & Capabilities */}
            <div className="lg:col-span-6 space-y-6">
              <div>
                <h3 className="text-lg font-bold text-white">Regulatory Bottlenecks Solved</h3>
                <ul className="mt-3 space-y-2">
                  {current.challenges.map((challenge, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                      <span className="text-red-400 font-bold">✕</span>
                      <span>{challenge}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-bold text-white">AegisData Synthetic Guarantees</h3>
                <ul className="mt-3 space-y-2">
                  {current.capabilities.map((cap, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                      <Check className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{cap}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => onLaunchWithDomain(current.id)}
                  className="flex items-center gap-2 rounded-lg bg-cyan-600 px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition-colors hover:bg-cyan-500"
                >
                  <span>Load {current.title} in Studio</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Right 6 cols: Active Schema Specification */}
            <div className="lg:col-span-6 rounded-xl border border-slate-800/80 bg-slate-950 p-5">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="text-xs font-semibold text-white">Active Schema Blueprint</div>
                <div className="text-[11px] text-slate-400">{schema.fields.length} Calibrated Fields</div>
              </div>

              <div className="mt-3 divide-y divide-slate-800/60 max-h-80 overflow-y-auto pr-1">
                {schema.fields.map((field) => (
                  <div key={field.name} className="py-2.5 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-mono font-medium text-slate-200">{field.name}</div>
                      <div className="text-[11px] text-slate-500">{field.description}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[10px] text-cyan-400 uppercase">{field.type}</span>
                      <span className="text-[10px] text-slate-400">({field.category})</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
