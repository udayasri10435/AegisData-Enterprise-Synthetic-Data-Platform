import React from 'react';
import { ShieldCheck, Download, Sparkles } from 'lucide-react';

interface TopNavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenExport: () => void;
  onOpenAudit: () => void;
}

export const TopNavigation: React.FC<TopNavigationProps> = ({
  activeTab,
  setActiveTab,
  onOpenExport,
  onOpenAudit,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6 lg:px-8">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('workbench');
          }}
          className="text-lg font-bold tracking-tight text-white transition-opacity hover:opacity-90"
        >
          AegisData
        </a>

        {/* Zone 2: Clean text navigation links with hover underlines */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-400">
          <button
            onClick={() => setActiveTab('workbench')}
            className={`transition-colors hover:text-white ${
              activeTab === 'workbench' ? 'text-cyan-400 underline decoration-cyan-400 underline-offset-8' : ''
            }`}
          >
            Synthetic Workbench
          </button>
          <button
            onClick={() => setActiveTab('domains')}
            className={`transition-colors hover:text-white ${
              activeTab === 'domains' ? 'text-cyan-400 underline decoration-cyan-400 underline-offset-8' : ''
            }`}
          >
            Sectors & Regulatory
          </button>
          <button
            onClick={() => setActiveTab('fidelity')}
            className={`transition-colors hover:text-white ${
              activeTab === 'fidelity' ? 'text-cyan-400 underline decoration-cyan-400 underline-offset-8' : ''
            }`}
          >
            Statistical Fidelity
          </button>
          <button
            onClick={() => setActiveTab('calculator')}
            className={`transition-colors hover:text-white ${
              activeTab === 'calculator' ? 'text-cyan-400 underline decoration-cyan-400 underline-offset-8' : ''
            }`}
          >
            Procurement & ROI
          </button>
        </nav>

        {/* Zone 3: Primary functional actions */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenAudit}
            className="flex items-center gap-2 rounded-lg border border-slate-700 bg-slate-900/80 px-3.5 py-2 text-xs font-semibold text-slate-200 transition-colors hover:border-slate-600 hover:bg-slate-800"
          >
            <ShieldCheck className="h-4 w-4 text-emerald-400" />
            <span>Audit Report</span>
          </button>
          <button
            onClick={onOpenExport}
            className="flex items-center gap-2 rounded-lg bg-cyan-600 px-4 py-2 text-xs font-semibold text-white shadow-sm transition-colors hover:bg-cyan-500 whitespace-nowrap"
          >
            <Download className="h-4 w-4" />
            <span>Export Pipeline</span>
          </button>
        </div>
      </div>
    </header>
  );
};
