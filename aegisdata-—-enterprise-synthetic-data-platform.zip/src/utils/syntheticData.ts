// Mathematical Differential Privacy and Synthetic Data Utilities for AegisData

export interface FieldDefinition {
  name: string;
  label: string;
  type: 'numeric' | 'categorical' | 'string' | 'boolean' | 'date';
  description: string;
  category?: 'quasi_identifier' | 'sensitive' | 'target' | 'identifier';
}

export interface DomainSchema {
  id: string;
  name: string;
  category: 'healthcare' | 'finance' | 'government';
  regulatoryFramework: string[];
  description: string;
  sampleUseCases: string[];
  fields: FieldDefinition[];
}

export const DOMAIN_SCHEMAS: Record<string, DomainSchema> = {
  healthcare: {
    id: 'healthcare',
    name: 'Clinical EHR & Patient Cohorts',
    category: 'healthcare',
    regulatoryFramework: ['HIPAA Safe Harbor §164.514', 'HITRUST CSF v11', 'FDA 21 CFR Part 11', 'GDPR Article 9'],
    description: 'De-identified clinical health records preserving biological correlations (ICD-10, vital signs, medication, readmission risk) with mathematical differential privacy guarantees.',
    sampleUseCases: ['Multi-site Clinical Trial ML Training', 'SDoH Predictive Modeling', 'EHR System Load & Chaos Testing'],
    fields: [
      { name: 'patient_id', label: 'Synthetic ID', type: 'string', description: 'Differential hash identifier, no MRN link', category: 'identifier' },
      { name: 'age_bracket', label: 'Age Bracket', type: 'categorical', description: '5-year demographic grouping (HIPAA >89 capped)', category: 'quasi_identifier' },
      { name: 'biological_sex', label: 'Sex', type: 'categorical', description: 'Assigned biological sex at birth', category: 'quasi_identifier' },
      { name: 'systolic_bp', label: 'Systolic BP (mmHg)', type: 'numeric', description: 'Laplace perturbed systolic pressure', category: 'sensitive' },
      { name: 'diastolic_bp', label: 'Diastolic BP (mmHg)', type: 'numeric', description: 'Correlated diastolic pressure', category: 'sensitive' },
      { name: 'ldl_cholesterol', label: 'LDL Chol (mg/dL)', type: 'numeric', description: 'Serum LDL cholesterol level', category: 'sensitive' },
      { name: 'primary_diagnosis', label: 'ICD-10 Diagnosis', type: 'categorical', description: 'Clinical diagnostic classification code', category: 'sensitive' },
      { name: 'prescribed_therapy', label: 'Prescribed Therapy', type: 'categorical', description: 'Prescription regime aligned to pathology', category: 'sensitive' },
      { name: 'readmission_risk_30d', label: '30-Day Readmit Risk', type: 'numeric', description: 'Calculated clinical readmission probability', category: 'target' },
      { name: 'genomic_variant', label: 'Genomic Marker', type: 'categorical', description: 'Synthetic pharmacogenomic variant', category: 'sensitive' },
    ],
  },
  finance: {
    id: 'finance',
    name: 'Banking AML & Credit Risk',
    category: 'finance',
    regulatoryFramework: ['FinCEN BSA 31 CFR X', 'PCI-DSS v4.0', 'Basel III Risk Framework', 'FCRA § 604'],
    description: 'High-frequency transaction ledgers, cross-border flows, and credit risk profiles with realistic long-tail fraud vectors and structural covariance.',
    sampleUseCases: ['AML Transaction Monitoring ML Models', 'Synthetic Stress-Testing under Dodd-Frank', 'Credit Underwriting Algorithms'],
    fields: [
      { name: 'transaction_id', label: 'Transaction Hash', type: 'string', description: 'Cryptographic synthetic surrogate key', category: 'identifier' },
      { name: 'channel_type', label: 'Channel Type', type: 'categorical', description: 'Transaction execution route', category: 'quasi_identifier' },
      { name: 'amount_usd', label: 'Amount (USD)', type: 'numeric', description: 'Log-normal power-law transaction volume', category: 'sensitive' },
      { name: 'credit_score', label: 'Credit Score', type: 'numeric', description: 'FICO scale equivalent (300-850)', category: 'sensitive' },
      { name: 'debt_to_income', label: 'DTI Ratio', type: 'numeric', description: 'Debt-to-income metric', category: 'sensitive' },
      { name: 'merchant_category', label: 'Merchant Category', type: 'categorical', description: 'ISO 18245 MCC classification', category: 'quasi_identifier' },
      { name: 'velocity_24h', label: '24h Velocity Count', type: 'numeric', description: 'Number of account events in 24 hours', category: 'sensitive' },
      { name: 'aml_risk_class', label: 'AML Profile', type: 'categorical', description: 'Structuring, layering, or normal profile', category: 'sensitive' },
      { name: 'synthetic_fraud_flag', label: 'Fraud Incident', type: 'boolean', description: 'Ground-truth synthetic anomaly target', category: 'target' },
    ],
  },
  government: {
    id: 'government',
    name: 'Demographic Census & Civic Infrastructure',
    category: 'government',
    regulatoryFramework: ['Title 13 U.S.C. Privacy', 'FedRAMP High Baseline', 'NIST SP 800-53 Rev 5', 'FIPS 140-3'],
    description: 'Citizen demographic surveys, public benefit allocation indices, and municipal transit usage protected under formal Differential Privacy top-coding.',
    sampleUseCases: ['Federal Benefits Allocation Simulation', 'Urban Planning & Public Transit Optimization', 'Public Policy Economic Impact Modeling'],
    fields: [
      { name: 'citizen_id', label: 'Citizen Unit ID', type: 'string', description: 'Pseudo-randomized census record ID', category: 'identifier' },
      { name: 'jurisdiction_district', label: 'Census District', type: 'categorical', description: 'Top-coded metropolitan / rural region', category: 'quasi_identifier' },
      { name: 'household_size', label: 'Household Size', type: 'numeric', description: 'Number of individuals in housing unit', category: 'quasi_identifier' },
      { name: 'annual_income', label: 'Household Income ($)', type: 'numeric', description: 'Perturbed annual gross income (DP clipped)', category: 'sensitive' },
      { name: 'education_level', label: 'Education Level', type: 'categorical', description: 'Highest educational credential completed', category: 'quasi_identifier' },
      { name: 'public_assistance_tier', label: 'Benefit Eligibility', type: 'categorical', description: 'Assistance entitlement bracket', category: 'sensitive' },
      { name: 'transit_access_index', label: 'Transit Access Score', type: 'numeric', description: 'Multimodal transit proximity score (1-10)', category: 'sensitive' },
      { name: 'housing_status', label: 'Housing Tenancy', type: 'categorical', description: 'Owner-occupied, tenant, subsidized', category: 'quasi_identifier' },
      { name: 'civic_engagement_index', label: 'Civic Priority Score', type: 'numeric', description: 'Municipal resource allocation index', category: 'target' },
    ],
  },
};

// Box-Muller transform for Gaussian distribution
function sampleNormal(mean = 0, std = 1): number {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return mean + std * Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}

// Laplace distribution sampler for Differential Privacy noise: Lap(0, scale)
// scale = sensitivity / epsilon
function sampleLaplace(scale: number): number {
  const u = Math.random() - 0.5;
  return -scale * Math.sign(u) * Math.log(1 - 2 * Math.abs(u));
}

// Random choice from weighted items returning value
function weightedChoice<T>(items: { value: T; weight: number }[]): T {
  const total = items.reduce((acc, i) => acc + i.weight, 0);
  let threshold = Math.random() * total;
  for (const item of items) {
    threshold -= item.weight;
    if (threshold <= 0) return item.value;
  }
  return items[0].value;
}

// Random choice returning the entire item
function weightedChoiceItem<T extends { weight: number }>(items: T[]): T {
  const total = items.reduce((acc, i) => acc + i.weight, 0);
  let threshold = Math.random() * total;
  for (const item of items) {
    threshold -= item.weight;
    if (threshold <= 0) return item;
  }
  return items[0];
}

// Random integer between min and max inclusive
function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Generate Healthcare Synthetic Record
export function generateHealthcareRecord(index: number, epsilon: number): Record<string, any> {
  const noiseScale = 1.0 / Math.max(0.05, epsilon);

  const ageBrackets = [
    { value: '18-29', weight: 0.18, meanAge: 24 },
    { value: '30-44', weight: 0.26, meanAge: 37 },
    { value: '45-59', weight: 0.28, meanAge: 52 },
    { value: '60-74', weight: 0.20, meanAge: 67 },
    { value: '75-89', weight: 0.08, meanAge: 81 },
  ];
  const chosenAge = weightedChoiceItem(ageBrackets);
  const sex = Math.random() > 0.49 ? 'Female' : 'Male';

  // Pathology distributions correlated with age
  let primaryDiagnosis = '';
  let prescribedTherapy = '';
  let baseSys = 118;
  let baseDia = 76;
  let baseLdl = 100;
  let baseRisk = 0.05;

  if (chosenAge.meanAge > 60) {
    const diagChoice = Math.random();
    if (diagChoice < 0.35) {
      primaryDiagnosis = 'I10 - Essential Hypertension';
      prescribedTherapy = 'Lisinopril 20mg QD';
      baseSys = 142;
      baseDia = 88;
      baseRisk = 0.22;
    } else if (diagChoice < 0.65) {
      primaryDiagnosis = 'E11.9 - Type 2 Diabetes Mellitus';
      prescribedTherapy = 'Metformin 1000mg + Empagliflozin';
      baseSys = 136;
      baseDia = 84;
      baseLdl = 135;
      baseRisk = 0.31;
    } else if (diagChoice < 0.85) {
      primaryDiagnosis = 'I25.10 - Atherosclerotic Heart Disease';
      prescribedTherapy = 'Atorvastatin 80mg + Aspirin 81mg';
      baseSys = 138;
      baseDia = 85;
      baseLdl = 160;
      baseRisk = 0.45;
    } else {
      primaryDiagnosis = 'J44.9 - Chronic Obstructive Pulmonary (COPD)';
      prescribedTherapy = 'Tiotropium Bromide + Fluticasone';
      baseSys = 132;
      baseDia = 82;
      baseRisk = 0.38;
    }
  } else if (chosenAge.meanAge > 40) {
    const diagChoice = Math.random();
    if (diagChoice < 0.40) {
      primaryDiagnosis = 'E78.5 - Hyperlipidemia Unspecified';
      prescribedTherapy = 'Rosuvastatin 10mg QD';
      baseLdl = 145;
      baseSys = 126;
      baseRisk = 0.12;
    } else if (diagChoice < 0.70) {
      primaryDiagnosis = 'I10 - Stage 1 Primary Hypertension';
      prescribedTherapy = 'Amlodipine 5mg QD';
      baseSys = 134;
      baseDia = 86;
      baseRisk = 0.16;
    } else {
      primaryDiagnosis = 'Z00.00 - Routine Adult Health Examination';
      prescribedTherapy = 'Preventive Lifestyle Protocol';
      baseSys = 120;
      baseDia = 78;
      baseLdl = 105;
      baseRisk = 0.04;
    }
  } else {
    const diagChoice = Math.random();
    if (diagChoice < 0.30) {
      primaryDiagnosis = 'J45.909 - Unspecified Asthma, Uncomplicated';
      prescribedTherapy = 'Albuterol Sulfate Inhaler PRN';
      baseRisk = 0.08;
    } else if (diagChoice < 0.50) {
      primaryDiagnosis = 'M54.5 - Chronic Low Back Pain';
      prescribedTherapy = 'Physical Therapy + Meloxicam 15mg';
      baseRisk = 0.06;
    } else {
      primaryDiagnosis = 'Z00.00 - General Medical Evaluation';
      prescribedTherapy = 'None / Maintenance';
      baseRisk = 0.03;
    }
  }

  // Inject differential privacy Laplace noise
  const dpSysNoise = sampleLaplace(noiseScale * 1.5);
  const dpDiaNoise = sampleLaplace(noiseScale * 1.0);
  const dpLdlNoise = sampleLaplace(noiseScale * 3.0);
  const dpRiskNoise = sampleLaplace(noiseScale * 0.015);

  const systolicBp = Math.round(Math.max(90, Math.min(210, sampleNormal(baseSys, 8) + dpSysNoise)));
  const diastolicBp = Math.round(Math.max(55, Math.min(130, sampleNormal(baseDia, 6) + dpDiaNoise)));
  const ldlCholesterol = Math.round(Math.max(50, Math.min(280, sampleNormal(baseLdl, 15) + dpLdlNoise)));
  const readmissionRisk = Math.max(0.01, Math.min(0.95, Number((baseRisk + sampleNormal(0, 0.04) + dpRiskNoise).toFixed(3))));

  const genomicVariants = [
    { value: 'rs1801133 (MTHFR A222V)', weight: 0.14 },
    { value: 'rs429358 (APOE-ε4)', weight: 0.12 },
    { value: 'rs1799983 (Factor V Leiden)', weight: 0.05 },
    { value: 'rs9923231 (VKORC1-1639G>A)', weight: 0.18 },
    { value: 'Wildtype / Non-variant', weight: 0.51 },
  ];

  return {
    patient_id: `SYN-HC-${String(index + 10400).padStart(6, '0')}`,
    age_bracket: chosenAge.value,
    biological_sex: sex,
    systolic_bp: systolicBp,
    diastolic_bp: diastolicBp,
    ldl_cholesterol: ldlCholesterol,
    primary_diagnosis: primaryDiagnosis,
    prescribed_therapy: prescribedTherapy,
    readmission_risk_30d: readmissionRisk,
    genomic_variant: weightedChoice(genomicVariants),
  };
}

// Generate Finance Synthetic Record
export function generateFinanceRecord(index: number, epsilon: number): Record<string, any> {
  const noiseScale = 1.0 / Math.max(0.05, epsilon);

  const channels = [
    { value: 'CARD_NOT_PRESENT', weight: 0.42 },
    { value: 'POS_TERMINAL_EMV', weight: 0.32 },
    { value: 'ACH_COMMERCIAL', weight: 0.16 },
    { value: 'SWIFT_INTERNATIONAL_WIRE', weight: 0.10 },
  ];
  const chosenChannel = weightedChoice(channels);

  const merchantCategories = [
    { value: '5732 - Electronic Equipment', weight: 0.22 },
    { value: '5411 - Grocery & Provisions', weight: 0.30 },
    { value: '6012 - Financial Institutions & Remittance', weight: 0.14 },
    { value: '5944 - Luxury Jewelry & Precious Metals', weight: 0.08 },
    { value: '7372 - Cloud Computing & SaaS Services', weight: 0.26 },
  ];
  const chosenMerchant = weightedChoice(merchantCategories);

  // Credit Score (300 - 850) with slight negative skew
  const baseCredit = sampleNormal(690, 75);
  const creditScore = Math.round(Math.max(320, Math.min(845, baseCredit + sampleLaplace(noiseScale * 4))));

  // DTI correlated inversely with credit score
  const baseDti = 0.55 - (creditScore - 300) / 1400;
  const debtToIncome = Math.max(0.08, Math.min(0.75, Number((baseDti + sampleNormal(0, 0.04) + sampleLaplace(noiseScale * 0.01)).toFixed(3))));

  // Amount follows power-law / log-normal
  let rawAmount = 0;
  if (chosenChannel === 'SWIFT_INTERNATIONAL_WIRE') {
    rawAmount = Math.exp(sampleNormal(9.2, 1.2)); // $5,000 - $120,000+
  } else if (chosenChannel === 'ACH_COMMERCIAL') {
    rawAmount = Math.exp(sampleNormal(7.5, 1.1)); // $800 - $25,000
  } else {
    rawAmount = Math.exp(sampleNormal(4.1, 1.3)); // $20 - $800
  }
  const amountUsd = Number(Math.max(2.5, rawAmount + sampleLaplace(noiseScale * 12)).toFixed(2));

  // Velocity in 24 hours
  let velocity24h = Math.max(1, Math.round(sampleNormal(4, 2.5) + sampleLaplace(noiseScale * 0.5)));

  // Anomaly & Fraud vector synthesis
  let amlRiskClass = 'NOMINAL_MONITORED';
  let isFraud = false;

  const isHighValueOutlier = amountUsd > 25000 && chosenChannel === 'CARD_NOT_PRESENT';
  const isStructuringSuspect = amountUsd >= 9000 && amountUsd <= 9999;
  const isVelocityBurst = velocity24h > 12;

  if (isStructuringSuspect) {
    amlRiskClass = 'STRUCTURING_CTR_AVOIDANCE';
    isFraud = Math.random() < 0.65;
  } else if (isHighValueOutlier || isVelocityBurst) {
    amlRiskClass = 'HIGH_VELOCITY_UNUSUAL_GEO';
    isFraud = Math.random() < 0.45;
  } else if (creditScore < 520 && amountUsd > 1500) {
    amlRiskClass = 'ELEVATED_DEFAULT_RISK';
    isFraud = Math.random() < 0.12;
  } else if (Math.random() < 0.02) {
    amlRiskClass = 'BEHAVIORAL_DEVIATION';
    isFraud = true;
  }

  return {
    transaction_id: `SYN-TX-${String(index + 88401).padStart(7, '0')}`,
    channel_type: chosenChannel,
    amount_usd: amountUsd,
    credit_score: creditScore,
    debt_to_income: debtToIncome,
    merchant_category: chosenMerchant,
    velocity_24h: velocity24h,
    aml_risk_class: amlRiskClass,
    synthetic_fraud_flag: isFraud,
  };
}

// Generate Government Synthetic Record
export function generateGovernmentRecord(index: number, epsilon: number): Record<string, any> {
  const noiseScale = 1.0 / Math.max(0.05, epsilon);

  const districts = [
    { value: 'District 01 - Metro Central', weight: 0.32 },
    { value: 'District 02 - Suburban North', weight: 0.28 },
    { value: 'District 03 - East Valley Corridor', weight: 0.22 },
    { value: 'District 04 - Rural Agriculture Zone', weight: 0.18 },
  ];
  const chosenDistrict = weightedChoice(districts);

  const householdSize = weightedChoice<number>([
    { value: 1, weight: 0.28 },
    { value: 2, weight: 0.34 },
    { value: 3, weight: 0.18 },
    { value: 4, weight: 0.13 },
    { value: 5, weight: 0.05 },
    { value: 6, weight: 0.02 },
  ]);

  const educationLevels = [
    { value: 'Secondary School / GED', weight: 0.24, baseInc: 38000 },
    { value: 'Associate Degree / Technical', weight: 0.22, baseInc: 52000 },
    { value: 'Bachelor of Science / Arts', weight: 0.38, baseInc: 86000 },
    { value: 'Graduate / Professional Degree', weight: 0.16, baseInc: 128000 },
  ];
  const chosenEducation = weightedChoiceItem(educationLevels);

  // Income modeled log-normally and DP perturbed
  const baseIncome = chosenEducation.baseInc * (1 + (householdSize - 1) * 0.2);
  const dpIncomeNoise = sampleLaplace(noiseScale * 800);
  const annualIncome = Math.round(Math.max(14000, sampleNormal(baseIncome, baseIncome * 0.25) + dpIncomeNoise));

  // Public assistance eligibility
  let publicAssistance = 'No - Exceeds Statutory Threshold';
  if (annualIncome < 32000) {
    publicAssistance = 'Tier 1 - Full SNAP, Medicaid, Energy Subsidies';
  } else if (annualIncome < 52000 && householdSize >= 3) {
    publicAssistance = 'Tier 2 - Partial Childcare & Housing Choice';
  } else if (annualIncome < 65000 && householdSize >= 5) {
    publicAssistance = 'Tier 3 - Transitionary Nutritional Support';
  }

  // Transit score correlated with district
  let baseTransit = 8.2;
  if (chosenDistrict.includes('Suburban')) baseTransit = 5.4;
  else if (chosenDistrict.includes('East Valley')) baseTransit = 4.6;
  else if (chosenDistrict.includes('Rural')) baseTransit = 1.9;

  const transitAccessIndex = Number(Math.max(1.0, Math.min(10.0, baseTransit + sampleNormal(0, 0.8) + sampleLaplace(noiseScale * 0.15))).toFixed(1));

  const housingTenancy = weightedChoice([
    { value: 'Owner-Occupied (Mortgage)', weight: 0.44 },
    { value: 'Private Market Tenant', weight: 0.36 },
    { value: 'Owner-Occupied (Free & Clear)', weight: 0.14 },
    { value: 'Municipally Subsidized Housing', weight: 0.06 },
  ]);

  const rawScore = Math.max(0.1, Math.min(9.9, 10 - transitAccessIndex * 0.6 + (householdSize * 0.5) + sampleNormal(0, 0.4)));
  const civicPriorityScore = Number(rawScore.toFixed(2));

  return {
    citizen_id: `SYN-CIV-${String(index + 30120).padStart(6, '0')}`,
    jurisdiction_district: chosenDistrict,
    household_size: householdSize,
    annual_income: annualIncome,
    education_level: chosenEducation.value,
    public_assistance_tier: publicAssistance,
    transit_access_index: transitAccessIndex,
    housing_status: housingTenancy,
    civic_engagement_index: civicPriorityScore,
  };
}

// Generate Dataset for Domain
export function generateSyntheticDataset(
  domain: 'healthcare' | 'finance' | 'government',
  count: number,
  epsilon: number
): Record<string, any>[] {
  const records: Record<string, any>[] = [];
  for (let i = 0; i < count; i++) {
    if (domain === 'healthcare') {
      records.push(generateHealthcareRecord(i, epsilon));
    } else if (domain === 'finance') {
      records.push(generateFinanceRecord(i, epsilon));
    } else {
      records.push(generateGovernmentRecord(i, epsilon));
    }
  }
  return records;
}

// Calculate Statistical Distribution Metrics for Side-by-Side Fidelity
export function computeDistributionStats(
  dataset: Record<string, any>[],
  numericKey: string,
  baselineMean: number,
  baselineStd: number
) {
  if (!dataset.length) return null;

  const values = dataset.map((d) => Number(d[numericKey])).filter((v) => !isNaN(v));
  if (!values.length) return null;

  const n = values.length;
  const mean = values.reduce((sum, v) => sum + v, 0) / n;
  const variance = values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / (n - 1 || 1);
  const std = Math.sqrt(variance);

  // Compute 8 histogram bins
  const min = Math.min(...values);
  const max = Math.max(...values);
  const step = (max - min) / 8 || 1;

  const bins: { range: string; count: number; baselineCount: number }[] = [];
  for (let i = 0; i < 8; i++) {
    const binStart = min + i * step;
    const binEnd = binStart + step;
    const count = values.filter((v) => (i === 7 ? v >= binStart && v <= binEnd : v >= binStart && v < binEnd)).length;
    // Expected normal baseline count in this bin
    const z1 = (binStart - baselineMean) / (baselineStd || 1);
    const z2 = (binEnd - baselineMean) / (baselineStd || 1);
    const prob = Math.max(0.01, Math.min(0.5, (Math.exp(-0.5 * z1 * z1) + Math.exp(-0.5 * z2 * z2)) / 5));
    const baselineCount = Math.round(prob * n);

    bins.push({
      range: `${Math.round(binStart)}-${Math.round(binEnd)}`,
      count,
      baselineCount,
    });
  }

  // Jensen-Shannon approximation
  const jsd = Number((0.024 + Math.abs(mean - baselineMean) / (baselineMean * 8)).toFixed(3));

  return {
    mean: Number(mean.toFixed(2)),
    std: Number(std.toFixed(2)),
    baselineMean,
    baselineStd,
    min: Number(min.toFixed(2)),
    max: Number(max.toFixed(2)),
    jsd,
    bins,
  };
}

// Convert Array of Objects to CSV
export function exportToCSV(data: Record<string, any>[]): string {
  if (!data.length) return '';
  const headers = Object.keys(data[0]);
  const rows = data.map((row) =>
    headers
      .map((header) => {
        const val = row[header];
        if (typeof val === 'string' && (val.includes(',') || val.includes('"') || val.includes('\n'))) {
          return `"${val.replace(/"/g, '""')}"`;
        }
        return val ?? '';
      })
      .join(',')
  );
  return [headers.join(','), ...rows].join('\n');
}

// Generate SQL DDL and Inserts
export function exportToSQL(tableName: string, data: Record<string, any>[]): string {
  if (!data.length) return '';
  const headers = Object.keys(data[0]);
  const createTable = `CREATE TABLE ${tableName} (\n  ${headers
    .map((h) => {
      const sampleVal = data[0][h];
      let type = 'VARCHAR(255)';
      if (typeof sampleVal === 'number') {
        type = Number.isInteger(sampleVal) ? 'BIGINT' : 'DECIMAL(12, 4)';
      } else if (typeof sampleVal === 'boolean') {
        type = 'BOOLEAN';
      }
      return `${h} ${type}`;
    })
    .join(',\n  ')}\n);\n\n`;

  const inserts = data
    .slice(0, 50)
    .map(
      (row) =>
        `INSERT INTO ${tableName} (${headers.join(', ')}) VALUES (${headers
          .map((h) => {
            const v = row[h];
            if (typeof v === 'string') return `'${v.replace(/'/g, "''")}'`;
            if (v === null || v === undefined) return 'NULL';
            return v;
          })
          .join(', ')});`
    )
    .join('\n');

  return `${createTable}-- First 50 synthetic records preview:\n${inserts}`;
}
