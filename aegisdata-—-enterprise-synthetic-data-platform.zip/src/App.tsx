import React, { useState } from 'react';
import { TopNavigation } from './components/TopNavigation';
import { HeroArchitecture } from './components/HeroArchitecture';
import { DomainShowcase } from './components/DomainShowcase';
import { WorkbenchGenerator } from './components/WorkbenchGenerator';
import { StatisticalFidelityLab } from './components/StatisticalFidelityLab';
import { EnterpriseRoiCalculator } from './components/EnterpriseRoiCalculator';
import { ComplianceAuditModal } from './components/ComplianceAuditModal';
import { ExportPipelineModal } from './components/ExportPipelineModal';
import { generateSyntheticDataset } from './utils/syntheticData';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('workbench');
  const [selectedDomain, setSelectedDomain] = useState<'healthcare' | 'finance' | 'government'>('healthcare');
  const [epsilon, setEpsilon] = useState<number>(1.0);
  const [kAnonymity, setKAnonymity] = useState<number>(10);

  // Initialize with pre-computed realistic synthetic dataset
  const [dataset, setDataset] = useState<Record<string, any>[]>(() =>
    generateSyntheticDataset('healthcare', 100, 1.0)
  );

  // Modals state
  const [isAuditModalOpen, setIsAuditModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);

  const handleDomainChange = (domain: 'healthcare' | 'finance' | 'government') => {
    setSelectedDomain(domain);
    const newRecords = generateSyntheticDataset(domain, 100, epsilon);
    setDataset(newRecords);
  };

  const handleLaunchWithDomain = (domain: 'healthcare' | 'finance' | 'government') => {
    handleDomainChange(domain);
    setActiveTab('workbench');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Bar Contract Navigation */}
      <TopNavigation
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenExport={() => setIsExportModalOpen(true)}
        onOpenAudit={() => setIsAuditModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* Hero Section */}
        <HeroArchitecture
          onSelectDomain={handleDomainChange}
          onExploreWorkbench={() => setActiveTab('workbench')}
        />

        {/* Tab View Container */}
        <div className="mx-auto max-w-7xl px-6 py-12 lg:px-8">
          {activeTab === 'workbench' && (
            <div className="space-y-12">
              <WorkbenchGenerator
                selectedDomain={selectedDomain}
                onSelectDomain={handleDomainChange}
                dataset={dataset}
                setDataset={setDataset}
                epsilon={epsilon}
                setEpsilon={setEpsilon}
                kAnonymity={kAnonymity}
                setKAnonymity={setKAnonymity}
                onOpenExport={() => setIsExportModalOpen(true)}
                onOpenAudit={() => setIsAuditModalOpen(true)}
              />

              {/* Inline preview of Statistical Fidelity below Workbench */}
              <div className="pt-8 border-t border-slate-800">
                <StatisticalFidelityLab dataset={dataset} domain={selectedDomain} />
              </div>
            </div>
          )}

          {activeTab === 'domains' && (
            <DomainShowcase
              selectedDomain={selectedDomain}
              onSelectDomain={handleDomainChange}
              onLaunchWithDomain={handleLaunchWithDomain}
            />
          )}

          {activeTab === 'fidelity' && (
            <div className="space-y-6">
              <StatisticalFidelityLab dataset={dataset} domain={selectedDomain} />
            </div>
          )}

          {activeTab === 'calculator' && (
            <div>
              <EnterpriseRoiCalculator />
            </div>
          )}
        </div>
      </main>

      {/* Clean Editorial Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-12 text-xs text-slate-500">
        <div className="mx-auto max-w-7xl px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <div className="font-bold text-slate-300 text-sm">AegisData Synthetics Inc.</div>
            <div className="mt-1">
              Enterprise Differential Privacy Platform for Healthcare, Financial Services, and Public Sector AI.
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-6">
            <span>HIPAA Safe Harbor (§164.514)</span>
            <span>·</span>
            <span>GDPR Recital 26</span>
            <span>·</span>
            <span>FinCEN BSA</span>
            <span>·</span>
            <span>FedRAMP High In-Process</span>
            <span>·</span>
            <span>NIST SP 800-53</span>
          </div>

          <div>
            &copy; {new Date().getFullYear()} AegisData. All rights reserved.
          </div>
        </div>
      </footer>

      {/* Compliance Audit Modal */}
      <ComplianceAuditModal
        isOpen={isAuditModalOpen}
        onClose={() => setIsAuditModalOpen(false)}
        domain={selectedDomain}
        epsilon={epsilon}
        kAnonymity={kAnonymity}
        recordCount={dataset.length}
      />

      {/* Export Pipeline Modal */}
      <ExportPipelineModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        dataset={dataset}
        domain={selectedDomain}
      />
    </div>
  );
}
